# LinkedIn Learning Python course by Joe Marini
# Example file for working with conditional statements


x, y = 10, 100
x = 100

# conditional flow uses if, elif, else
if x < y:
  st = "x is less than y"
elif x == y:
  st = "x is equal to y"
else:
  st = "x is greater than y"
print(st)

# conditional statements let you use "a if C else b"
st = "x is less than y" if x < y else "x is greater than or equal to y"
print(st)